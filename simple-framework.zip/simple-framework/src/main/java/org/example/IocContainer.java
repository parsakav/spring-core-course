package org.example;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
public class IocContainer {
    private Map<Class<?>,Object> beans = new HashMap<>();

    public void registerComponents(Class<?>... classess) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        for (Class<?> clazz:classess) {
            if(clazz.isAnnotationPresent(Component.class)){
                System.out.println("F");
                Constructor<?>[] constructors = clazz.getConstructors();
                for (Constructor constructor:constructors) {
                    if(constructor.isAnnotationPresent(Inject.class)){
                    Object object=    createBeabWithConstructorInjection(constructor);
                        System.out.println("Put");
                    beans.put(clazz,object);
                    } else {
                        beans.put(clazz,clazz.getDeclaredConstructor().newInstance());
                    }
                }
                Object clazzObject=beans.get(clazz);
                fieldInjection(clazzObject);

            }


        }

    }

    private Object createBeabWithConstructorInjection(Constructor constructor) throws InvocationTargetException, InstantiationException, IllegalAccessException {
        Class[] parameterTypes = constructor.getParameterTypes();
        Object[] parameter = new Object[parameterTypes.length];
        for (int i = 0; i < parameter.length; i++) {
            Object bean=beans.get(parameterTypes[i]);
            parameter[i]=bean;
            if(bean==null){
                throw new RuntimeException("Unresolved dependency:"+parameterTypes[i].getName());
            }
        }
       return constructor.newInstance(parameter);

    }
    private void fieldInjection(Object instance) throws InvocationTargetException, InstantiationException, IllegalAccessException {
        Field[] fields = instance.getClass().getDeclaredFields();
        for(Field field : fields){
            if(field.isAnnotationPresent(Autowired.class)){
               Object bean= beans.get(field.getType());
                if(bean==null){
                    throw new RuntimeException("Unresolved dependency:"+field.getType().getName());
                }
                field.setAccessible(true);
                field.set(instance,bean);
            }
        }


    }

    public <T> T getBeans(Class<T> clazz){
        System.out.println(beans.get(clazz)==null);
        return clazz.cast(beans.get(clazz));
    }
}
