package org.example;

import java.lang.reflect.InvocationTargetException;
import java.security.Provider;

public class Main {

    public Main(String a,Integer b){

    }
    public static void main(String[] args) throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
        IocContainer iocContainer = new IocContainer();

        iocContainer.registerComponents(ServiceA.class,ServiceB.class,ServiceC.class);
        ServiceA serviceA = iocContainer.getBeans(ServiceA.class);
        ServiceB serviceB = iocContainer.getBeans(ServiceB.class);
        ServiceC serviceC = iocContainer.getBeans(ServiceC.class);
        serviceC.print();
    }
}
