package org.example;

@Component
public class ServiceA {


    void print(){
        System.out.println("Service A");
    }
}
