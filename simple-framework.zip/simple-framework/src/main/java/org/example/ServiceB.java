package org.example;

@Component
public class ServiceB {
    private final ServiceA serviceA;


    @Inject
    public ServiceB(ServiceA serviceA) {
        this.serviceA = serviceA;
    }
    public void print(){
        serviceA.print();
    }
}
