package org.example;

@Component
public class ServiceC {
    @Autowired
    private ServiceB serviceB;

    void print(){
        serviceB.print();
    }
}
