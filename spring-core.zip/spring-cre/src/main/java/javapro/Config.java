package javapro;public class Config {
}
