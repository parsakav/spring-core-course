package javapro;

public class EmailMessageService implements MessageService {
    @Override
    public void send(String msg) {

    }
}
