package javapro;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        //IOC container

        //solid
        // dependency inversion principle


        //IOC container



        //Singlethon != Prototype
        ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
        Member member= (Member) ctx.getBean("member");
        member.setName("Parsa");
        System.out.println(member);
        Member member2= ctx.getBean(Member.class);
        System.out.println(member2);

    }
}
