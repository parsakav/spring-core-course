package javapro;

public interface MessageService {

    void send(String msg);
}
