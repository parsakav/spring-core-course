package javapro;

public class NotificationSender {


    //thight coupling

    //loose coupling
    private final MessageService smsMessageService;

    public NotificationSender(MessageService smsMessageService) {
        this.smsMessageService = smsMessageService;
    }


    public void sendNotif(String txt){
        smsMessageService.send(txt);
    }
}
