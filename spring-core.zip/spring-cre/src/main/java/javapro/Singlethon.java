package javapro;

public class Singlethon {

   private static  Singlethon singlethon=null ;

    private Singlethon(){

    }

    public static  Singlethon getInstance(){

if(singlethon==null){
    synchronized (Singlethon.class) {
        if(singlethon==null) {
            singlethon = new Singlethon();
        }
    }
}
        return singlethon;

    }
}
