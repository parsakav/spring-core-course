package javapro;

public class SmsMessageService implements MessageService {
    @Override
    public void send(String msg) {

    }
}
