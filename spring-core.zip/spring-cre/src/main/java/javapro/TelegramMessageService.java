package javapro;

public class TelegramMessageService implements MessageService{
    @Override
    public void send(String msg) {

    }
}
